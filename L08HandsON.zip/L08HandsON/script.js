$(document).ready(function(){
    $("header").hover(function(){
        $(this).css("color", "green");
    }, function(){
        $(this).css("color", "black");
    });
});

$(document).ready(function(){
    $("p").click(function(){
        $("p").text("Jquery is a fast, javascript libary that makes many tasks  easier and simpler to accomplish. A javascript libary contains pre-written javascript which makes developing applications a bit easier for the developer. This means Jquery is not a a language, but an extension of javascript. It takes many lines of javascript code, which we would have had to write ourselves before Jquery, and compresses it");
    });
});

$(document).ready(function(){
    $("li").dblclick(function(){
        $("li").hide();
    });
});

$(document).ready(function(){
    $("input").keydown(function(){
        $(this).css("color","red");
    });
});